Tanmoy Sir's World
===================
Free static website.

To publish free:
1. Create a GitHub account at github.com.
2. Create a new repository named: tanmoy-sirs-world
3. Upload index.html.
4. Open Settings -> Pages.
5. Select Deploy from branch -> main -> / (root).
6. GitHub will give you a free address like:
   https://YOUR-USERNAME.github.io/tanmoy-sirs-world/

Before publishing, replace your-email@example.com in index.html with your real email address.
